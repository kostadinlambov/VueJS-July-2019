export const tasks = [
  {
    id: 0,
    name: 'Go to Gym'
  },
  {
    id: 1,
    name: 'Go to Store'
  },
  {
    id: 2,
    name: 'Feed the cat'
  },
  {
    id: 3,
    name: 'Wash dishes'
  },
  {
    id: 4,
    name: 'Fix the car'
  }
]